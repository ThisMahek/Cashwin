<?php 
	include('includes/header.php');
	include('includes/sidebar.php');
?>

    <div class="content-wrapper">

        <div class="page-content fade-in-up">
            <div class="ibox">
                <div class="ibox-body">
                    <div class="row" style="padding-bottom: 7px;">
                        <div class="col-md-6">
                            <h5 class="font-strong mb-4">App setings</h5></div>
                        
                    </div>
                    <?php echo form_open_multipart(''); ?>
                        <div class="row">
                           <div class="col-md-6">
                                <div class="form-group mb-4">
                                    <label>Share Message</label>
                                    <input type="text" name="message" class="form-control" value="<?= $setting->message ?>" required="required">
                                </div>
                            </div>
                            <div class="col-md-6">
                                <div class="form-group mb-4">
                                    <label>Account Holder Name</label>
                                    <input type="text" name="account_holder_name" class="form-control" value="<?= $setting->account_holder_name ?>" required="required">
                                </div>
                            </div>
                            
                            <div class="col-md-6">
                                <div class="form-group mb-4">
                                    <label>Account Number</label>
                                    <input type="text" name="account_number" class="form-control" value="<?= $setting->account_number ?>" required="required">
                                </div>
                            </div>
                            <div class="col-md-6">
                                <div class="form-group mb-4">
                                    <label>IFSC Code</label>
                                    <input type="text" name="ifsc_code" class="form-control" value="<?= $setting->ifsc_code ?>" required="required">
                                </div>
                            </div>
                            <div class="col-md-6">
                                <div class="form-group mb-4">
                                    <label>App Link</label>
                                    <input type="text" name="app_link" class="form-control" value="<?= $setting->app_link ?>" required="required">
                                </div>
                            </div>
                            
                            <!-- <div class="col-md-6">-->
                            <!--    <div class="form-group mb-4">-->
                            <!--        <label>Share Message</label>-->
                            <!--        <input type="text" name="message" class="form-control" value="<?= $setting->message ?>" required="required">-->
                            <!--    </div>-->
                            <!--</div>-->
                            
                             <div class="col-md-6">
                                <div class="form-group mb-4">
                                    <label>Google UPI Payment Id</label>
                                    <input type="text" name="google_upi" class="form-control" value="<?= $setting->google_upi ?>" required="required">
                                </div>
                            </div>
                            
                             <div class="col-md-6">
                                <div class="form-group mb-4">
                                    <label>Phone Pe UPI Payment Id</label>
                                    <input type="text" name="phonepe_upi" class="form-control" value="<?= $setting->phonepe_upi ?>" required="required">
                                </div>
                            </div>
                            
                             <div class="col-md-6">
                                <div class="form-group mb-4">
                                    <label>Other UPI Payment Id</label>
                                    <input type="text" name="upi" class="form-control" value="<?= $setting->upi ?>" required="required">
                                </div>
                            </div>
                            
                           
                            
                            
                             <div class="col-md-6">
                                <div class="form-group mb-4">
                                    <div class="row mt-5">
                                   <div class="col-md-1 p-0 m-0">
                                    <input type="checkbox" name="is_show_message" class="form-control" value="<?= $setting->is_show_message ?>"  <?=($setting->is_show_message==1)?'checked':''?> required="required">
                                    </div>
                                     <div class="col-md-11 p-0 m-0">
                                     <label>Show Msg (ON/OFF)</label>
                                     </div>
                                     </div>
                                </div>
                            </div>
                            
                            
                            
                               <div class="col-md-6">
                                <div class="form-group mb-4">
                                    <label>Minimum Deposite</label>
                                    <input type="text" name="min_amount" class="form-control" value="<?= $setting->min_amount ?>" required="required">
                                </div>
                            </div>
                            
                            
                               <div class="col-md-6">
                                <div class="form-group mb-4">
                                    <label>Maximum Deposite</label>
                                    <input type="text" name="maximum_deposite" class="form-control" value="<?= $setting->maximum_deposite ?>" required="required">
                                </div>
                            </div>
                            
                               <div class="col-md-6">
                                <div class="form-group mb-4">
                                    <label>Minimum Withdrawal</label>
                                    <input type="text" name="w_amount" class="form-control" value="<?= $setting->w_amount ?>" required="required">
                                </div>
                            </div>
                            
                              <div class="col-md-6">
                                <div class="form-group mb-4">
                                    <label>Maximum Withdrawal</label>
                                    <input type="text" name="maximum_withdrawal" class="form-control" value="<?= $setting->maximum_withdrawal ?>" required="required">
                                </div>
                            </div>
                            
                           
                            
                            <div class="col-md-6">
                                <div class="form-group mb-4">
                                    <label>Minimum Transfer</label>
                                    <input type="text" name="minimum_transfer" class="form-control" value="<?= $setting->minimum_transfer ?>" required="required">
                                </div>
                            </div>
                            
                            
                            <div class="col-md-6">
                                <div class="form-group mb-4">
                                    <label>Maximum Transfer</label>
                                    <input type="text" name="maximum_transfer" class="form-control" value="<?= $setting->maximum_transfer ?>" required="required">
                                </div>
                            </div>
                            
                            <div class="col-md-6">
                                <div class="form-group mb-4">
                                    <label>Welcome Bonus</label>
                                    <input type="text" name="welcome_bonus" class="form-control" value="<?= $setting->welcome_bonus ?>" required="required">
                                </div>
                            </div>
                            <div class="col-md-6">
                                <div class="form-group mb-4">
                                    <label>Withdraw Open Time</label>
                                    <input type="time" name="withdraw_open_time" class="form-control" value="<?= $setting->withdraw_open_time ?>" required="required">
                                </div>
                            </div>
                            <div class="col-md-6">
                                <div class="form-group mb-4">
                                    <label>Withdraw Close Time</label>
                                    <input type="time" name="withdraw_close_time" class="form-control" value="<?= $setting->withdraw_close_time ?>" required="required">
                                </div>
                            </div>
                               <div class="col-md-6">
                                <div class="form-group mb-4">
                                    <div class="row mt-5">
                                   <div class="col-md-1 p-0 m-0">
                                    <input type="checkbox" name="is_global_batting" class="form-control" value="<?= $setting->is_global_batting ?>"  <?=($setting->is_global_batting==1)?'checked':''?> required="required">
                                    </div>
                                     <div class="col-md-11 p-0 m-0">
                                     <label>Global Batting</label>
                                     </div>
                                     </div>
                                </div>
                            </div>
                            <!--<div class="col-md-6">-->
                            <!--    <div class="form-group mb-4">-->
                            <!--        <label>Message</label>-->
                            <!--        <input type="text" name="message" class="form-control" value="<?= $setting->message ?>" required="required">-->
                            <!--    </div>-->
                            <!--</div>-->
                            <!--<div class="col-md-6">-->
                            <!--    <div class="form-group mb-4">-->
                            <!--        <label>Home Text</label>-->
                            <!--        <input type="text" name="hometext" class="form-control" value="<?= $setting->home_text ?>" required="required">-->
                            <!--    </div>-->
                            <!--</div>-->
                            <!--<div class="col-md-6">-->
                            <!--    <div class="form-group mb-4">-->
                            <!--        <label>Privacy Policy</label>-->
                            <!--        <input type="text" name="privacy_pol" class="form-control" value="<?= $setting->privacy_policy ?>" required="required">-->
                            <!--    </div>-->
                            <!--</div>-->
                            <!--<div class="col-md-6">-->
                            <!--    <div class="form-group mb-4">-->
                            <!--        <label>Withdraw Text</label>-->
                            <!--        <input type="text" name="withdrawtext" class="form-control" value="<?= $setting->withdraw_text ?>" required="required">-->
                            <!--    </div>-->
                            <!--</div>-->
                            <!--<div class="col-md-6">-->
                            <!--    <div class="form-group mb-4">-->
                            <!--        <label>Add Point Text</label>-->
                            <!--        <input type="text" name="add_fund_text" class="form-control" value="<?= $setting->add_fund_text ?>" required="required">-->
                            <!--    </div>-->
                            <!--</div>-->
                            <!--<div class="col-md-6">-->
                            <!--    <div class="form-group mb-4">-->
                            <!--        <label>Withdraw No.</label>-->
                            <!--        <input type="text" name="withdrawnumber" class="form-control" value="<?= $setting->withdraw_no ?>" required="required">-->
                            <!--    </div>-->
                            <!--</div>-->
                            <!--<div class="col-md-6">-->
                            <!--    <div class="form-group mb-4">-->
                            <!--        <label>UPI ID</label>-->
                            <!--        <input type="text" name="upi" class="form-control" value="<?= $setting->upi ?>">-->
                            <!--    </div>-->
                            <!--</div>-->
                            <!--<hr/>-->
                            <!--<div class="col-md-6">-->
                            <!--    <div class="form-group mb-4">-->
                            <!--        <label>Mobile No.</label>-->
                            <!--        <input type="text" name="mobile_no" class="form-control" value="<?= $site_setting->mobile ?>" required="required">-->
                            <!--    </div>-->
                            <!--</div><div class="col-md-6">-->
                            <!--    <div class="form-group mb-4">-->
                            <!--        <label>Whatsapp No.</label>-->
                            <!--        <input type="text" name="whatsapp_no" class="form-control" value="<?= $site_setting->whatsapp ?>" required="required">-->
                            <!--    </div>-->
                            <!--</div>-->
                        </div>

                </div>
                <div class="ibox-footer">
                    <button type="submit" name="submitw" class="btn btn-primary">Update</button>
                    <!-- <button class="btn btn-outline-secondary" type="reset">Cancel</button> -->
                </div>
                </form>

            </div>
            
            
            
            
            
        </div>
        
        
        
        
    </div>
    <!-- END PAGE CONTENT-->

    <?php include('includes/footer.php')?>