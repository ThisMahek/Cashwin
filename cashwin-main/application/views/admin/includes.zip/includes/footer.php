            <?php if(!isset($no_footer)): ?>
            <footer class="page-footer">
                <div class="font-13">2022 © <b>Cash Win</b> All Rights Reserved</div>
                <div></div>
                <div class="to-top"><i class="fa fa-angle-double-up"></i></div>
            </footer>
            <?php endif; ?>
        </div>
</div>
</div>
    <!-- START SEARCH PANEL-->
    <!--<form class="search-top-bar" action="">-->
    <!--    <input class="form-control search-input" type="text" placeholder="Search...">-->
    <!--    <button class="reset input-search-icon"><i class="ti-search"></i></button>-->
    <!--    <button class="reset input-search-close" type="button"><i class="ti-close"></i></button>-->
    <!--</form>-->
   
    <div class="sidenav-backdrop backdrop"></div>
    <div class="preloader-backdrop">
        <div class="page-preloader">Loading</div>
    </div>
    
    <script src="<?php echo base_url() ?>assets/resources/vendors/jquery/dist/jquery.min.js"></script>
    <script src="<?php echo base_url() ?>assets/resources/vendors/popper.js/dist/umd/popper.min.js"></script>
    <script src="<?php echo base_url() ?>assets/resources/vendors/bootstrap/dist/js/bootstrap.min.js"></script>
    <script src="<?php echo base_url() ?>assets/resources/vendors/metisMenu/dist/metisMenu.min.js"></script>
    <script src="<?php echo base_url() ?>assets/resources/vendors/jquery-slimscroll/jquery.slimscroll.min.js"></script>
    <script src="<?php echo base_url() ?>assets/resources/vendors/jquery-idletimer/dist/idle-timer.min.js"></script>
    <script src="<?php echo base_url() ?>assets/resources/vendors/toastr/toastr.min.js"></script>
    <script src="<?php echo base_url() ?>assets/resources/vendors/jquery-validation/dist/jquery.validate.min.js"></script>
    <script src="<?php echo base_url() ?>assets/resources/vendors/bootstrap-select/dist/js/bootstrap-select.min.js"></script>
    <!-- PAGE LEVEL PLUGINS-->
    <script src="<?php echo base_url() ?>assets/resources/vendors/chart.js/dist/Chart.min.js"></script>
    <script src="<?php echo base_url() ?>assets/resources/vendors/jquery.easy-pie-chart/dist/jquery.easypiechart.min.js"></script>
    <script src="<?php echo base_url() ?>assets/resources/vendors/jvectormap/jquery-jvectormap-2.0.3.min.js"></script>
    <script src="<?php echo base_url() ?>assets/resources/vendors/jvectormap/jquery-jvectormap-world-mill-en.js"></script>
    <!-- CORE SCRIPTS-->
      <!--<script src="<?php echo base_url() ?>assets/resources/js/scripts/dashboard_ecommerce.js"></script>-->
   
    
     <!--<script src="<?php echo base_url() ?>assets/resources/js/scripts/form-plugins.js"></script>-->
    <!-- PAGE LEVEL SCRIPTS-->
     <script src="<?php echo base_url() ?>assets/resources/vendors/bootstrap-datepicker/dist/js/bootstrap-datepicker.min.js"></script>
     <!--<script src="<?php echo base_url() ?>assets/resources/vendors/dataTables/datatables.min.js"></script>-->
     <script src="<?php echo base_url() ?>assets/resources/vendors/jquery-knob/dist/jquery.knob.min.js"></script>
    <script src="<?php echo base_url() ?>assets/resources/vendors/ion.rangeSlider/js/ion.rangeSlider.min.js"></script>
    <script src="<?php echo base_url() ?>assets/resources/vendors/moment/min/moment.min.js"></script>
   
    <script src="<?php echo base_url() ?>assets/resources/vendors/smalot-bootstrap-datetimepicker/js/bootstrap-datetimepicker.min.js"></script>
    <script src="<?php echo base_url() ?>assets/resources/vendors/bootstrap-daterangepicker/daterangepicker.js"></script>
    <script src="<?php echo base_url() ?>assets/resources/vendors/clockpicker/dist/bootstrap-clockpicker.min.js"></script>
    <script src="<?php echo base_url() ?>assets/resources/vendors/jquery-minicolors/jquery.minicolors.min.js"></script>
    <script src="<?php echo base_url() ?>assets/resources/vendors/multiselect/js/jquery.multi-select.js"></script>
    <script src="<?php echo base_url() ?>assets/resources/vendors/bootstrap-tagsinput/dist/bootstrap-tagsinput.min.js"></script>
    <script src="<?php echo base_url() ?>assets/resources/vendors/bootstrap-maxlength/src/bootstrap-maxlength.js"></script>
    <script src="<?php echo base_url() ?>assets/resources/vendors/bootstrap-touchspin/dist/jquery.bootstrap-touchspin.min.js"></script>
    <!--<script src="<?php echo base_url() ?>assets/resources/js/scripts/dashboard_visitors.js"></script>-->
     <script type="text/javascript" charset="utf8" src="//cdn.datatables.net/1.13.1/js/jquery.dataTables.min.js"></script>
     <script>
      $(document).ready( function () {
            $('.datatable').DataTable();
        } );
    //     $(function() {
    //         $('#datatable').DataTable({
    //             pageLength: 10,
    //             fixedHeader: true,
    //             responsive: true,
    //             "sDom": 'rtip',
    //             columnDefs: [{
    //                 targets: 'no-sort',
    //                 orderable: false
    //             }]
    //         });

    //         var table = $('#datatable').DataTable();
    //         $('#key-search').on('keyup', function() {
    //             table.search(this.value).draw();
    //         });
    //         $('#type-filter').on('change', function() {
    //             table.column(4).search($(this).val()).draw();
    //         });
    //     });
    </script>
    <script>
    //     $(function() {
    //         $('#datatable2').DataTable({
    //             pageLength: 15,
    //             fixedHeader: true,
    //             responsive: true,
    //             "sDom": 'rtip',
    //             columnDefs: [{
    //                 targets: 'no-sort',
    //                 orderable: false
    //             }]
    //         });

    //         var table = $('#datatable2').DataTable();
    //         $('#key-search').on('keyup', function() {
    //             table.search(this.value).draw();
    //         });
    //         $('#type-filter').on('change', function() {
    //             table.column(4).search($(this).val()).draw();
    //         });
    //     });
    </script>
    <script>
    //     $(function() {
    //         $('#datatable1').DataTable({
    //             pageLength: 15,
    //             "order": [[ 2, "desc" ]],
    //             "sDom": 'rtip',
    //             columnDefs: [{
    //                 targets: 'no-sort',
    //                 orderable: false
    //             }]
    //         });

    //         var table1 = $('#datatable1').DataTable();
    //         $('#key-search').on('keyup', function() {
    //             table1.search(this.value).draw();
    //         });
    //         $('#type-filter').on('change', function() {
    //             table1.column(4).search($(this).val()).draw();
    //         });
    //     });
    
    $('#example').dataTable( {
  "ordering": false
} );
     </script>
     
     
     
     
     
    <!-- PAGE LEVEL PLUGINS-->
    <script src="<?php echo base_url() ?>assets/resources/vendors/summernote/dist/summernote.min.js"></script>
    <script src="<?php echo base_url() ?>assets/resources/vendors/bootstrap-markdown/js/bootstrap-markdown.js"></script>
    <!-- CORE SCRIPTS-->
    <script src="<?php echo base_url() ?>assets/resources/js/app.min.js"></script>
    <!-- menu js -->
    <!-- <script src="https://code.jquery.com/jquery-1.12.4.js"></script> -->
  <script src="https://code.jquery.com/ui/1.12.1/jquery-ui.js"></script>
  <script>
  $( function() {
    $( "#sortable" ).sortable();
    $( "#sortable" ).disableSelection();
  } );
  </script>
    <!-- PAGE LEVEL SCRIPTS-->
    <!--<script src="<?php echo base_url() ?>assets/resources/js/scripts/form-plugins.js"></script>-->
    <script>
        $(function() {
            $('#summernote').summernote();
            $('#summernote_air').summernote({
                airMode: true
            });
        });
    </script>
    <script type="text/javascript">
    function fileValidation(){
    var fileInput = document.getElementById('file');
    var filePath = fileInput.value;
    var allowedExtensions = /(\.jpg|\.jpeg|\.png|\.gif)$/i;
    if(!allowedExtensions.exec(filePath)){
        alert('Please upload file having extensions .jpeg/.jpg/.png/.gif only.');
        fileInput.value = '';
        return false;
    }else{
        //Image preview
        if (fileInput.files && fileInput.files[0]) {
            var reader = new FileReader();
            reader.onload = function(e) {
                document.getElementById('imagePreview').innerHTML = '<img src="'+e.target.result+'" height="100"/>';
            };
            reader.readAsDataURL(fileInput.files[0]);
        }
    }
}
</script>
</body>

</html>