<?php include('includes/header.php')?>
      <style>
      body{
          background-color: #eeeeee;
      }
      .text-white{
          color:white !important;
      }
        
        .cid-qyXbTBAY8L .navbar.navbar-short .navbar-logo img{
        height:45px!important;
    }
         .RECORD {
         background-color: #fff;
         color: #000;
         font-weight: 700;
         font-style: italic;
         font-size: largeD225972056
         border-width: 5px;
         border-color: #5f9ea0;
         border-style: groove;
         text-shadow: 1px 1px #ffd700;
         padding-top: 10px;
         padding-bottom: 10px;
         }
         .d{
         font-size: 25px;
         }
         @media only screen and (max-width: 600px) {
         .font-size {
         font-size:25px;
         }
         }
         @media only screen and (max-width: 600px) {
         .d {
         font-size: 14px!important;
         }
         }
         
         .navbar-dropdown .navbar-logo img {
    height: 45px;
    transition: all 0.3s ease-in-out;
    /*transform: scale(1.5);*/
}

.cid-qyXbTBAY8L .navbar { min-height: 80px; transition: all .3s; background: cadetblue; }
.cid-qyXbTBAY8L .navbar.navbar-short {
    background: cadetblue !important;
    min-height: 80px;
}
.heading{
    position:absolute;
    top:200px;
    right:230px;
    color:white;
}
.mytble2 {
    background-color: #5f9ea0!important;
}
.mytble2 tr:nth-child(odd) {
    color: white;
}
.table-bordered {
    border: 1px solid #d8bb6c;
}
.bg-primary {
    background-color: #5f9ea0 !important;
}
.bg-warning {
    background-color: #5f9ea0 !important;
}
  .table-color {
    border-style: solid;
    border-color: #7d0506;
    background-color: #f9f5a2fc;
    color: #000000;
}
.button2 {
    top: 70px;
    right: 10px;
    z-index: 99;
    border: none;
    outline: none;
    background-color:black;
    color: #fff !important;
    cursor: pointer;
    padding: 10px;
    border-radius: 3px;
    text-decoration: none;
} 
@media only screen and (min-width: 768px) {
 .position-absolute{
    position: absolute;
    left: 50%;

    bottom: -60px;
}   
}

@media only screen and (max-width: 600px) {
.position-absolute{
    position: absolute;
    left: 8rem;

    bottom: -60px;
}
}
      </style>
  
      <section style="margin-top:100px; margin-bottom:80px;">
              <center>
        <div id="top"></div>
        <a href="#bottom" class="button2 mb-5" style="cursor:pointer;"> Go to Bottom </a>
        <br> <br>
    </center>
         <div class="container bg-white table-color">
            <center>
               <h2 style="color:black;font-weight:bold; text-transform:uppercase;padding-top:20px;"><?php echo $chart[0]['name']. " ". "Chart"?></h2>
            </center>
            <div class="row">
                <div class="col-md-1"></div>
                <div class="col-md-10">
                    <div class="RECORD mb-4" style="width:100%;">
               <table cellspacing="0" style="text-align: center;width:100%;padding:0px" class="table table-striped">
                  <?php 
                     $round = 5;
                     if($sat)
                         $round = 6;
                     ?>
                  <tbody>
                     <?php
                        //$chartdate = array_reverse($chartdate);
                        foreach($chartdate as $chs) {
                            ?>
                     <tr>
                        <?php
                           $date=$chs['s'];
                           for($ii=0; $ii<$round;$ii++):
                           $ch = $this->Chart_Model->getChartDetailName($chart[0]['name'],$date);
                           if($ch==null){ ?>
                        <td style="padding:10px;"><span class="d" style="color:red"><?php echo '**'; ?></span></td>
                        <?php } else { ?>
                        <td style="padding:10px;"><span class="d" style="color:"><?php echo $ch['result_num']; ?></span></td>
                        <?php }
                           if($date==date('Y-m-d'))
                               break;            
                           $date= date('Y-m-d',strtotime('+1 days',strtotime($date)));
                           endfor;
                           }
                           ?>
                     </tr>
                  </tbody>
               </table>
            </div>
                </div>
                <div class="col-md-2"></div>
            </div>
            <div class="position-absolute">
             <center>
               
         <div id="bottom"></div>
         <a class="button2" style="color:white;" onclick="document.body.scrollTop=0;document.documentElement.scrollTop=0"> Go to Top </a>
      </center>
      </div>
         </div>
      </section>
<?php include('includes/footer.php')?>